{
        "name" : "uml_test",
        "version" : "0.1",
        "author" : "Tiny",
        "website" : "http://openerp.com",
        "category" : "Unknown",
        "description": """  """,
        "depends" : ['base'],
        "init_xml" : [ ],
        "demo_xml" : [ ],
        "update_xml" : ['uml_test_view.xml'],
        "installable": True
}